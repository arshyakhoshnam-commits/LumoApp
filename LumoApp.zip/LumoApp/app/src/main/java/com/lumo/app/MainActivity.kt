package com.lumo.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LumoUI() }
    }
}

@Composable
fun LumoUI() {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("lumo", 0) }
    var on by remember { mutableStateOf(p.getBoolean("on", false)) }
    var msg by remember { mutableStateOf(p.getString("msg", DEFAULT_MSG)!!) }
    var game by remember { mutableStateOf("") }
    fun open(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8B5CF6))) {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("🌙 LumoApp", style = MaterialTheme.typography.headlineLarge)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("پاسخ خودکار (آفلاین‌ام)", Modifier.weight(1f))
                            Switch(checked = on, onCheckedChange = { on = it; p.edit().putBoolean("on", it).apply() })
                        }
                        OutlinedTextField(value = msg, onValueChange = { msg = it; p.edit().putString("msg", it).apply() },
                            modifier = Modifier.fillMaxWidth(), label = { Text("متن پیام") })
                        Button(onClick = { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                            modifier = Modifier.fillMaxWidth()) { Text("۱) دسترسی به اعلان‌ها (روبیکا و ...)") }
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("🎮 جستجوی بازی")
                        OutlinedTextField(value = game, onValueChange = { game = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("اسم بازی") })
                        Button(onClick = { open(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode("$game download apk")))) },
                            modifier = Modifier.fillMaxWidth()) { Text("جستجو در مرورگر") }
                        OutlinedButton(onClick = { open(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(game)))) },
                            modifier = Modifier.fillMaxWidth()) { Text("جستجو در گوگل‌پلی") }
                    }
                }
                OutlinedButton(onClick = { open(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) },
                    modifier = Modifier.fillMaxWidth()) { Text("دسترسی به فایل‌ها") }
            }
        }
    }
}
