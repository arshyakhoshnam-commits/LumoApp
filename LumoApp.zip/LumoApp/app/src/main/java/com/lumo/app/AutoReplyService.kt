package com.lumo.app

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class AutoReplyService : NotificationListenerService() {
    private val last = HashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val p = getSharedPreferences("lumo", 0)
        if (!p.getBoolean("on", false) || sbn.packageName == packageName) return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val title = n.extras.getString(Notification.EXTRA_TITLE) ?: ""
        val k = sbn.packageName + title
        val now = System.currentTimeMillis()
        if (now - (last[k] ?: 0L) < 3_600_000L) return
        val a = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        val ri = a.remoteInputs
        val b = Bundle()
        b.putCharSequence(ri[0].resultKey, p.getString("msg", DEFAULT_MSG))
        val i = Intent()
        RemoteInput.addResultsToIntent(ri, i, b)
        try { a.actionIntent.send(this, 0, i); last[k] = now } catch (e: Exception) {}
    }
}

const val DEFAULT_MSG = "🌙 الان آفلاینم، آنلاین شدم جواب می‌دم 💬"
